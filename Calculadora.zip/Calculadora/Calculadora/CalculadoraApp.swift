//
//  CalculadoraApp.swift
//  Calculadora
//
//  Created by Felipe Porto on 14/04/23.
//

import SwiftUI

@main
struct CalculadoraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
